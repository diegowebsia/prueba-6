import { NextResponse } from 'next/server';
import { getSessionUser } from '@/lib/auth';
import { createAdminClient } from '@/lib/supabase/admin';
import { systemLog } from '@/lib/logger';

export const dynamic = 'force-dynamic';

/**
 * Alta en el PLAN GRATUITO (sin tarjeta y sin Stripe).
 *
 * POST /api/tenants/start
 *  · Requiere sesión.
 *  · Si el usuario ya tiene empresa, no crea otra (1 empresa por cuenta) y
 *    devuelve `alreadyExists: true` para que la UI le lleve al panel.
 *  · Si no la tiene, crea la empresa con `plan: 'free'` y estado `active`
 *    (el plan Gratuito da acceso completo al panel con sus límites).
 *
 * Los planes Pro y Business siguen pasando por Stripe
 * (`/api/stripe/checkout` + webhook), que crea/actualiza la misma empresa.
 */
export async function POST() {
  const user = await getSessionUser();
  if (!user) return NextResponse.json({ error: 'No autenticado.' }, { status: 401 });

  const admin = createAdminClient();
  if (!admin) {
    return NextResponse.json(
      { error: 'Supabase no configurado en el servidor.', code: 'demo' },
      { status: 503 },
    );
  }

  const { data: existing } = await admin
    .from('tenants')
    .select('id, plan, subscription_status')
    .eq('owner_id', user.id)
    .order('created_at', { ascending: true })
    .limit(1)
    .maybeSingle();

  if (existing?.id) {
    return NextResponse.json({ ok: true, tenantId: existing.id, alreadyExists: true });
  }

  const baseName = (user.email ?? 'mi-negocio').split('@')[0] ?? 'mi-negocio';
  const slug = `${baseName
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '')
    .slice(0, 40) || 'negocio'}-${Date.now().toString(36)}`;

  const { data: created, error } = await admin
    .from('tenants')
    .insert({
      name: `Negocio de ${baseName}`,
      slug,
      owner_id: user.id,
      owner_email: user.email,
      plan: 'free',
      subscription_status: 'active',
    })
    .select('id')
    .single();

  if (error || !created) {
    await systemLog('error', 'tenants.start', error?.message ?? 'No se pudo crear la empresa gratuita', {
      user: user.email,
    });
    return NextResponse.json({ error: 'No se pudo crear tu empresa. Inténtalo de nuevo.' }, { status: 500 });
  }

  await admin.from('memberships').insert({ tenant_id: created.id, user_id: user.id, role: 'owner' });

  await systemLog('info', 'tenants.start', `Empresa creada en plan Gratuito: ${baseName}`, {
    tenantId: created.id,
    user: user.email,
  });

  return NextResponse.json({ ok: true, tenantId: created.id, alreadyExists: false });
}

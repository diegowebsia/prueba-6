import type { NextRequest } from 'next/server';
import { NextResponse } from 'next/server';
import { createServerClient } from '@supabase/ssr';
import { isTrialExpired, TRIAL_DAYS } from '@/lib/plans';

/**
 * ReviewFlow AI v3.8.0 — Middleware de seguridad y negocio.
 *
 * - `/admin/*`: solo SUPERADMIN_EMAILS (verificación 1 de 2). Es un panel
 *   interno PRIVADO: no se enlaza desde ninguna página pública.
 * - `/dashboard/*`: sesión + SUSCRIPCIÓN CON ACCESO (trialing/active).
 *   Sin acceso → /bienvenido con el motivo:
 *     · `trial-ended`  → la prueba de {TRIAL_DAYS} días venció y no se completó
 *                        el pago del día 8 (corte automático del panel).
 *     · `past-due`     → impago (invoice.payment_failed).
 *     · `canceled`     → suscripción cancelada / pausada por Stripe.
 *     · `suspended`    → suspensión manual desde /admin.
 *     · `no-access`    → registrado sin plan contratado.
 *   El plan Gratuito entra con estado `active` (sin Stripe). Cero acceso infinito
 *   sin plan. Si la comprobación falla por un error de
 *   infraestructura, se permite el paso (fail-open) y el dashboard muestra el
 *   paywall; cada API re-verifica de todos modos (defensa en profundidad).
 */
export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  const isAdminRoute = pathname === '/admin' || pathname.startsWith('/admin/');
  const isDashboardRoute = pathname === '/dashboard' || pathname.startsWith('/dashboard/');
  // Rutas de IA: filtro de sesión en el borde (la suscripción y la cuota se
  // verifican contra la BD en cada ruta con `enforceAi()`).
  const isAiRoute = pathname === '/api/ai' || pathname.startsWith('/api/ai/');

  if (!isAdminRoute && !isDashboardRoute && !isAiRoute) {
    return NextResponse.next();
  }

  const res = NextResponse.next();

  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const supabaseAnon = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

  if (!supabaseUrl || !supabaseAnon) {
    // Sin Supabase no hay datos reales que proteger: `?demo=1` permite previsualizar
    // /admin y /dashboard con datos de ejemplo (misma regla en ambas rutas).
    const demoBypass = req.nextUrl.searchParams.get('demo');
    if (demoBypass === '1') return res;
    if (isAiRoute) {
      return NextResponse.json(
        { error: 'Supabase no configurado en el servidor. La IA está en modo demo.', code: 'demo' },
        { status: 503 },
      );
    }
    const loginUrl = req.nextUrl.clone();
    loginUrl.pathname = '/login';
    loginUrl.searchParams.set('redirect', pathname);
    loginUrl.searchParams.set('reason', 'configure-supabase');
    return NextResponse.redirect(loginUrl);
  }

  const supabase = createServerClient(supabaseUrl, supabaseAnon, {
    cookies: {
      get(name: string) {
        return req.cookies.get(name)?.value;
      },
      set(name: string, value: string, options: any) {
        res.cookies.set({ name, value, ...options });
      },
      remove(name: string, options: any) {
        res.cookies.set({ name, value: '', ...options });
      },
    },
  });

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    // Las rutas de API responden JSON 401 (no redirección) para que el panel
    // muestre el aviso correcto y nunca llame a la IA sin sesión.
    if (isAiRoute) {
      return NextResponse.json({ error: 'No autenticado.', code: 'unauthenticated' }, { status: 401 });
    }
    const loginUrl = req.nextUrl.clone();
    loginUrl.pathname = '/login';
    loginUrl.searchParams.set('redirect', pathname);
    return NextResponse.redirect(loginUrl);
  }

  if (isAdminRoute) {
    const raw = process.env.SUPERADMIN_EMAILS ?? '';
    const allowed = raw
      .split(',')
      .map((e) => e.trim().toLowerCase())
      .filter(Boolean);
    const email = (user.email ?? '').toLowerCase();

    if (allowed.length === 0 || !email || !allowed.includes(email)) {
      const deniedUrl = req.nextUrl.clone();
      deniedUrl.pathname = '/login';
      deniedUrl.searchParams.set('error', 'forbidden');
      return NextResponse.redirect(deniedUrl);
    }
    return res;
  }

  // Dashboard: corte por suscripción (trial de 7 días, impagos, cancelaciones).
  if (isDashboardRoute) {
    const verdict = await checkSubscriptionAccess(supabaseUrl, user.id);
    if (verdict && verdict.allowed === false) {
      const welcomeUrl = req.nextUrl.clone();
      // /bienvenido no está protegido: permite reactivar y pagar.
      welcomeUrl.pathname = '/bienvenido';
      welcomeUrl.searchParams.set('reason', verdict.reason);
      if (verdict.reason === 'trial-ended') welcomeUrl.searchParams.set('trial', String(TRIAL_DAYS));
      const response = NextResponse.redirect(welcomeUrl);
      response.headers.set('X-RF-Access-Denied', verdict.reason);
      return response;
    }
  }

  return res;
}

type AccessVerdict =
  | { allowed: true }
  | { allowed: false; reason: 'trial-ended' | 'past-due' | 'canceled' | 'suspended' | 'no-access' };

type TenantAccessRow = {
  subscription_status: string;
  suspended: boolean;
  trial_ends_at: string | null;
};

/**
 * `{ allowed: true }` = acceso · `{ allowed: false, reason }` = corte a
 * /bienvenido · `null` = no se pudo comprobar (fail-open; el dashboard y cada
 * API re-verifican de todos modos).
 */
async function checkSubscriptionAccess(
  supabaseUrl: string,
  userId: string,
): Promise<AccessVerdict | null> {
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!serviceKey) return null;
  try {
    const r = await fetch(
      `${supabaseUrl}/rest/v1/tenants?owner_id=eq.${encodeURIComponent(userId)}` +
        `&select=subscription_status,suspended,trial_ends_at`,
      {
        headers: { apikey: serviceKey, Authorization: `Bearer ${serviceKey}` },
        cache: 'no-store',
      },
    );
    if (!r.ok) return null;
    const rows = (await r.json()) as TenantAccessRow[];
    if (!rows || rows.length === 0) return { allowed: false, reason: 'no-access' };

    // Cualquier empresa activa y no suspendida da acceso al panel.
    const usable = rows.filter(
      (t) =>
        !t.suspended &&
        (t.subscription_status === 'active' || t.subscription_status === 'trialing') &&
        // Día 8 sin pago completado → la prueba caducó aunque Stripe aún diga `trialing`.
        !isTrialExpired(t.subscription_status, t.trial_ends_at),
    );
    if (usable.length > 0) return { allowed: true };

    if (rows.some((t) => t.suspended)) return { allowed: false, reason: 'suspended' };
    if (rows.some((t) => isTrialExpired(t.subscription_status, t.trial_ends_at))) {
      return { allowed: false, reason: 'trial-ended' };
    }
    if (rows.some((t) => t.subscription_status === 'past_due')) return { allowed: false, reason: 'past-due' };
    if (rows.some((t) => t.subscription_status === 'canceled' || t.subscription_status === 'paused')) {
      return { allowed: false, reason: 'canceled' };
    }
    return { allowed: false, reason: 'no-access' };
  } catch {
    return null;
  }
}

export const config = {
  matcher: ['/admin/:path*', '/dashboard/:path*', '/api/ai/:path*', '/api/ai'],
};

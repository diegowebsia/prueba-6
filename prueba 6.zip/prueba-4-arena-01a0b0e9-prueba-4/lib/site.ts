/**
 * ReviewFlow AI — Datos del sitio y de la empresa.
 * ⚠️ ACCIÓN MANUAL: edita este fichero con tus datos fiscales reales
 * (ver docs/GUIA_PASOS_MANUALES.md paso 1). Se usan en el footer y en las
 * páginas legales (/aviso-legal, /privacidad, /terminos, /cookies).
 */
export const SITE = {
  brand: 'ReviewFlow AI',
  tagline: 'Todas tus reseñas. Una sola bandeja. Respuestas con IA.',
  // ---- Datos fiscales (LSSI-CE art. 10) — RELLENAR ----
  company: '[NOMBRE FISCAL S.L.]',
  cif: '[CIF/NIF]',
  address: '[CALLE, Nº, CP, CIUDAD, ESPAÑA]',
  email: 'legal@[tudominio.com]',
  supportEmail: 'soporte@[tudominio.com]',
  domain: '[tudominio.com]',
  // ---- Planes (deben coincidir con Stripe) ----
  plans: {
    free: { name: 'Gratuito', price: '0 €', period: '/mes' },
    pro: { name: 'Pro', price: '29 €', period: '/mes' },
    business: { name: 'Business', price: '79 €', period: '/mes' },
  },
};
